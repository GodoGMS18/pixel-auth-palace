import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import useAuth from "../../hooks/useAuth";
import api, { MOCK_STORAGE_KEYS } from "../../lib/api";
import Otp6 from "../../components/auth/Otp6";

const readLastVerificationCode = () => {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(MOCK_STORAGE_KEYS.lastVerificationCode);
};

export default function VerifyEmailForm() {
  const { verifyEmail } = useAuth();
  const [search] = useSearchParams();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [lastCode, setLastCode] = useState<string | null>(() => readLastVerificationCode());

  useEffect(() => {
    const fromParam = search.get("email");
    const local = typeof window !== "undefined" ? window.localStorage.getItem("hyow_pending_email") : null;
    setEmail(fromParam || local || "");
  }, [search]);

  useEffect(() => {
    let t: ReturnType<typeof setTimeout> | undefined;
    if (cooldown > 0) {
      t = setTimeout(() => setCooldown((c) => c - 1), 1000);
    }
    return () => {
      if (t) clearTimeout(t);
    };
  }, [cooldown]);

  const valid = useMemo(() => /^[0-9]{6}$/.test(code), [code]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMsg(null);
    if (!email) {
      setError("Email is required.");
      return;
    }
    if (!valid) {
      setError("Please enter the 6-digit code.");
      return;
    }
    setLoading(true);
    try {
      await verifyEmail(email, code);
      if (typeof window !== "undefined") {
        window.localStorage.removeItem("hyow_pending_email");
        window.localStorage.removeItem(MOCK_STORAGE_KEYS.lastVerificationCode);
      }
      setLastCode(null);
      setMsg("Email verified! Redirecting to sign in…");
      setTimeout(() => navigate("/login"), 900);
    } catch (e: any) {
      setError(e?.response?.data?.message || "Verification failed");
    } finally {
      setLoading(false);
    }
  };

  const resend = async () => {
    setError(null);
    setMsg(null);
    if (!email) {
      setError("Email is required to resend the code.");
      return;
    }
    try {
      await api.post("/auth/resend-verification", { email });
      const storedCode = readLastVerificationCode();
      setLastCode(storedCode);
      setMsg(storedCode ? `Code resent to your email. Use ${storedCode}.` : "Code resent to your email.");
      setCooldown(60);
    } catch (e: any) {
      setError(e?.response?.data?.message || "Could not resend code");
    }
  };

  useEffect(() => {
    setLastCode(readLastVerificationCode());
  }, []);

  return (
    <form onSubmit={onSubmit} className="bg-gray-800 p-6 rounded-xl shadow-xl max-w-md w-full">
      <h1 className="text-2xl font-semibold text-white mb-4">Verify your email</h1>

      <label className="block mb-4">
        <span className="block text-sm font-medium text-gray-200 mb-1">Email</span>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          className="w-full rounded-lg border bg-gray-900 text-white px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500"
          required
        />
      </label>

      <div className="mb-2 text-sm text-gray-300">Enter the 6‑digit code we sent to your email.</div>
      {lastCode && <div className="mb-2 text-xs text-indigo-300">Mock code: {lastCode}</div>}
      <div className="mb-4"><Otp6 value={code} onChange={setCode} /></div>

      {msg && <div className="text-green-400 text-sm mb-2">{msg}</div>}
      {error && <div className="text-red-400 text-sm mb-2">{error}</div>}

      <button
        type="submit"
        disabled={loading || !valid}
        className={`w-full rounded-lg ${valid ? "bg-indigo-600 hover:bg-indigo-500" : "bg-indigo-900/60"} transition text-white py-2 font-medium`}
      >
        {loading ? "Verifying…" : "Verify"}
      </button>

      <div className="flex justify-between items-center text-sm text-gray-300 mt-3">
        <button type="button" onClick={resend} disabled={cooldown > 0} className="hover:underline disabled:opacity-50">
          Resend code {cooldown > 0 ? `(${cooldown}s)` : ""}
        </button>
        <Link to="/login" className="hover:underline">Back to sign in</Link>
      </div>
    </form>
  );
}
