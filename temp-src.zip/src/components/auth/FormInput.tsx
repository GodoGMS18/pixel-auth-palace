import React from "react";

type Props = React.InputHTMLAttributes<HTMLInputElement> & {
  label: string;
  error?: string;
};

export default function FormInput({ label, error, ...props }: Props) {
  return (
    <label className="block mb-4">
      <span className="block text-sm font-medium text-gray-200 mb-1">{label}</span>
      <input
        {...props}
        className={`w-full rounded-lg border bg-gray-900 text-white px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500 ${props.className || ""}`}
      />
      {error && <span className="text-xs text-red-400 mt-1 block">{error}</span>}
    </label>
  );
}
