import React, { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import api, { MOCK_STORAGE_KEYS } from "../../lib/api";
import FormInput from "./FormInput";

const readResetToken = () => {
  if (typeof window === "undefined") return "";
  return window.localStorage.getItem(MOCK_STORAGE_KEYS.lastResetToken) || "";
};

export default function ResetPasswordForm() {
  const navigate = useNavigate();
  const [search] = useSearchParams();
  const tokenFromLink = search.get("token") || readResetToken();
  const [token, setToken] = useState(tokenFromLink);
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [tokenHint] = useState(() => readResetToken());

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setMsg(null);
    try {
      await api.post("/auth/reset-password", { token, new_password: password });
      setMsg("Password updated. Redirecting to sign in…");
      if (typeof window !== "undefined") {
        window.localStorage.removeItem(MOCK_STORAGE_KEYS.lastResetToken);
      }
      setTimeout(() => navigate("/login"), 1000);
    } catch (e: any) {
      setError(e?.response?.data?.message || "Reset failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={onSubmit} className="bg-gray-800 p-6 rounded-xl shadow-xl max-w-md w-full">
      <h1 className="text-2xl font-semibold text-white mb-4">Reset password</h1>
      <FormInput label="Reset token" value={token} onChange={(e) => setToken(e.target.value)} required />
      {tokenHint && <div className="text-xs text-indigo-300 -mt-3 mb-3">Mock reset token: {tokenHint}</div>}
      <FormInput label="New password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
      {msg && <div className="text-green-400 text-sm mb-2">{msg}</div>}
      {error && <div className="text-red-400 text-sm mb-2">{error}</div>}
      <button type="submit" disabled={loading} className="w-full rounded-lg bg-indigo-600 hover:bg-indigo-500 transition text-white py-2 font-medium">
        {loading ? "Updating…" : "Update password"}
      </button>
    </form>
  );
}
