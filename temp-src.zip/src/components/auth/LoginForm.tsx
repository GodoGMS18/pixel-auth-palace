import React, { useState } from "react";
import { useNavigate, Link, useLocation } from "react-router-dom";
import useAuth from "../../hooks/useAuth";
import FormInput from "./FormInput";
import { DEMO_CREDENTIALS } from "../../lib/api";

export default function LoginForm() {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const loc = useLocation();

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const user = await login(email, password);
      if (!user.isVerified) {
        if (typeof window !== "undefined") {
          window.localStorage.setItem("hyow_pending_email", email);
        }
        navigate("/verify-email");
      } else {
        const redirectTo = (loc.state as any)?.from || "/";
        navigate(redirectTo, { replace: true });
      }
    } catch (e: any) {
      setError(e?.response?.data?.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={onSubmit} className="bg-gray-800 p-6 rounded-xl shadow-xl max-w-md w-full">
      <h1 className="text-2xl font-semibold text-white mb-4">Sign in</h1>
      <FormInput
        label="Email"
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="you@example.com"
        required
      />
      <FormInput
        label="Password"
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="••••••••"
        required
      />
      <div className="text-xs text-indigo-300 mb-2">Demo account: {DEMO_CREDENTIALS.email} / {DEMO_CREDENTIALS.password}</div>
      {error && <div className="text-red-400 text-sm mb-2">{error}</div>}
      <button
        type="submit"
        disabled={loading}
        className="w-full rounded-lg bg-indigo-600 hover:bg-indigo-500 transition text-white py-2 font-medium"
      >
        {loading ? "Signing in…" : "Sign in"}
      </button>
      <div className="flex justify-between text-sm text-gray-300 mt-3">
        <Link to="/register" className="hover:underline">Create account</Link>
        <Link to="/forgot-password" className="hover:underline">Forgot password?</Link>
      </div>
    </form>
  );
}
