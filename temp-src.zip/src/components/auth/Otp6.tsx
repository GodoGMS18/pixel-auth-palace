import React, { useEffect, useRef, useState } from "react";

type Props = {
  value?: string;
  length?: number;
  onChange?: (code: string) => void;
  disabled?: boolean;
};

export default function Otp6({ value = "", length = 6, onChange, disabled }: Props) {
  const [digits, setDigits] = useState<string[]>(Array.from({ length }, (_, i) => value[i] || ""));
  const refs = useRef<Array<HTMLInputElement | null>>([]);

  useEffect(() => {
    const arr = Array.from({ length }, (_, i) => value[i] || "");
    setDigits(arr);
  }, [value, length]);

  const focus = (i: number) => refs.current[i]?.focus();

  const emit = (arr: string[]) => {
    const code = arr.join("");
    onChange?.(code);
  };

  const onInput = (i: number, v: string) => {
    if (disabled) return;

    const only = v.replace(/\D/g, "");
    if (!only) {
      const next = [...digits];
      next[i] = "";
      setDigits(next);
      emit(next);
      return;
    }

    if (only.length > 1) {
      const next = [...digits];
      for (let k = 0; k < only.length && i + k < length; k++) {
        next[i + k] = only[k];
      }
      setDigits(next);
      emit(next);
      const last = Math.min(i + only.length, length - 1);
      focus(last);
      return;
    }
    // Single digit
    const next = [...digits];
    next[i] = only;
    setDigits(next);
    emit(next);
    if (i < length - 1 && only) focus(i + 1);
  };

  const onKeyDown = (i: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (disabled) return;
    const key = e.key;
    if (key === "Backspace") {
      if (digits[i]) {
        const next = [...digits];
        next[i] = "";
        setDigits(next);
        emit(next);
      } else if (i > 0) {
        focus(i - 1);
      }
      e.preventDefault();
      return;
    }
    if (key === "ArrowLeft" && i > 0) {
      focus(i - 1);
      e.preventDefault();
      return;
    }
    if (key === "ArrowRight" && i < length - 1) {
      focus(i + 1);
      e.preventDefault();
      return;
    }
  };

  return (
    <div className="flex items-center gap-2">
      {Array.from({ length }).map((_, i) => (
        <input
          key={i}
          ref={(el) => {
            refs.current[i] = el;
          }}
          inputMode="numeric"
          pattern="[0-9]*"
          aria-label={`Verification digit ${i + 1}`}
          className="w-12 h-12 text-center text-xl rounded-lg border bg-gray-900 text-white outline-none focus:ring-2 focus:ring-indigo-500"
          maxLength={6} // allow paste of all 6 at once
          value={digits[i] || ""}
          onChange={(e) => onInput(i, e.target.value)}
          onKeyDown={(e) => onKeyDown(i, e)}
          disabled={disabled}
        />
      ))}
    </div>
  );
}
