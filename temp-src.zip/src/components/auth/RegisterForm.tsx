import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import useAuth from "../../hooks/useAuth";
import FormInput from "./FormInput";

export default function RegisterForm() {
  const { register } = useAuth();
  const [first_name, setFirstName] = useState("");
  const [last_name, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      await register({ first_name, last_name, email, password });
      navigate("/verify-email");
    } catch (e: any) {
      setError(e?.response?.data?.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={onSubmit} className="bg-gray-800 p-6 rounded-xl shadow-xl max-w-md w-full">
      <h1 className="text-2xl font-semibold text-white mb-4">Create account</h1>
      <div className="grid grid-cols-2 gap-3">
        <FormInput label="First name" value={first_name} onChange={(e) => setFirstName(e.target.value)} required />
        <FormInput label="Last name" value={last_name} onChange={(e) => setLastName(e.target.value)} required />
      </div>
      <FormInput label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
      <FormInput label="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
      {error && <div className="text-red-400 text-sm mb-2">{error}</div>}
      <button type="submit" disabled={loading} className="w-full rounded-lg bg-indigo-600 hover:bg-indigo-500 transition text-white py-2 font-medium">
        {loading ? "Creating…" : "Create account"}
      </button>
      <div className="text-sm text-gray-300 mt-3">
        Already have an account? <Link to="/login" className="hover:underline">Sign in</Link>
      </div>
    </form>
  );
}
