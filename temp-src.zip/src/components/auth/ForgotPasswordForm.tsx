import React, { useState } from "react";
import { Link } from "react-router-dom";
import api, { MOCK_STORAGE_KEYS } from "../../lib/api";
import FormInput from "./FormInput";

const readResetToken = () => {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(MOCK_STORAGE_KEYS.lastResetToken);
};

export default function ForgotPasswordForm() {
  const [email, setEmail] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [tokenHint, setTokenHint] = useState<string | null>(() => readResetToken());

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setMsg(null);
    try {
      await api.post("/auth/forgot-password", { email });
      const hint = readResetToken();
      setTokenHint(hint);
      setMsg(hint ? `Use reset token ${hint} on the next screen.` : "If that email exists, a reset link has been sent.");
    } catch (e: any) {
      setError(e?.response?.data?.message || "Request failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={onSubmit} className="bg-gray-800 p-6 rounded-xl shadow-xl max-w-md w-full">
      <h1 className="text-2xl font-semibold text-white mb-4">Forgot password</h1>
      <FormInput label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
      {tokenHint && <div className="text-xs text-indigo-300 mb-2">Mock reset token: {tokenHint}</div>}
      {msg && <div className="text-green-400 text-sm mb-2">{msg}</div>}
      {error && <div className="text-red-400 text-sm mb-2">{error}</div>}
      <button type="submit" disabled={loading} className="w-full rounded-lg bg-indigo-600 hover:bg-indigo-500 transition text-white py-2 font-medium">
        {loading ? "Sending…" : "Send reset link"}
      </button>
      <div className="text-sm text-gray-300 mt-3">
        <Link to="/login" className="hover:underline">Back to sign in</Link>
      </div>
    </form>
  );
}
