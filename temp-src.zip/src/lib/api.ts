import type { AuthTokens, LoginResponse, User } from "../types/auth";

export type { AuthTokens };

const ACCESS_TOKEN_STORAGE_KEY = "hyow_access_token";
const DB_STORAGE_KEY = "hyow_mock_db_v1";
const SESSION_STORAGE_KEY = "hyow_mock_last_session";
export const DEMO_CREDENTIALS = Object.freeze({ email: "demo@example.com", password: "Password123" });
export const MOCK_STORAGE_KEYS = {
  lastVerificationCode: "hyow_mock_last_verification_code",
  lastResetToken: "hyow_mock_last_reset_token",
} as const;

const isBrowser = typeof window !== "undefined" && typeof window.localStorage !== "undefined";

let accessToken: string | null = null;

type MockUser = User & {
  password: string;
  verifyCode: string | null;
  resetToken: string | null;
};

type MockDb = {
  users: MockUser[];
  sessions: Record<string, { userId: string; created_at: string }>;
};

const now = () => new Date().toISOString();

const delay = async (ms = 300) => new Promise((resolve) => setTimeout(resolve, ms));

const randomId = () => `user_${Math.random().toString(36).slice(2, 10)}`;
const randomToken = () => `tok_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
const randomCode = () => `${Math.floor(100000 + Math.random() * 900000)}`;

const readStorage = <T>(key: string, fallback: T): T => {
  if (!isBrowser) return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch (error) {
    console.warn(`[mock-api] Failed to read storage key ${key}`, error);
    return fallback;
  }
};

const writeStorage = <T>(key: string, value: T) => {
  if (!isBrowser) return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.warn(`[mock-api] Failed to write storage key ${key}`, error);
  }
};

const removeStorage = (key: string) => {
  if (!isBrowser) return;
  try {
    window.localStorage.removeItem(key);
  } catch (error) {
    console.warn(`[mock-api] Failed to remove storage key ${key}`, error);
  }
};

const loadDb = (): MockDb => {
  const db = readStorage<MockDb | null>(DB_STORAGE_KEY, null);
  if (db) return db;

  const seeded: MockDb = {
    users: [
      {
        id: "demo-user",
        first_name: "Demo",
        last_name: "User",
        email: "demo@example.com",
        password: "Password123",
        isVerified: true,
        created_at: now(),
        updated_at: now(),
        verifyCode: null,
        resetToken: null,
      },
    ],
    sessions: {},
  };

  writeStorage(DB_STORAGE_KEY, seeded);
  return seeded;
};

const saveDb = (db: MockDb) => {
  writeStorage(DB_STORAGE_KEY, db);
};

const toPublicUser = (user: MockUser): User => ({
  id: user.id,
  first_name: user.first_name,
  last_name: user.last_name,
  email: user.email,
  isVerified: user.isVerified,
  created_at: user.created_at,
  updated_at: user.updated_at,
});

export class HttpError extends Error {
  response: { status: number; data: { message: string; details?: unknown } };
  constructor(status: number, message: string, details?: unknown) {
    super(message);
    this.name = "HttpError";
    this.response = { status, data: { message, details } };
  }
}

export const setAccessToken = (token: string | null) => {
  accessToken = token;
  if (!isBrowser) return;
  if (token) {
    window.localStorage.setItem(ACCESS_TOKEN_STORAGE_KEY, token);
    window.localStorage.setItem(SESSION_STORAGE_KEY, token);
  } else {
    window.localStorage.removeItem(ACCESS_TOKEN_STORAGE_KEY);
    removeStorage(SESSION_STORAGE_KEY);
  }
};

export const getAccessToken = (): string | null => {
  if (accessToken) return accessToken;
  if (!isBrowser) return null;
  const stored = window.localStorage.getItem(ACCESS_TOKEN_STORAGE_KEY);
  accessToken = stored;
  return stored;
};

const resolveSessionToken = () => {
  const token = getAccessToken();
  if (token) return token;
  if (!isBrowser) return null;
  const stored = window.localStorage.getItem(SESSION_STORAGE_KEY);
  if (stored) {
    setAccessToken(stored);
    return stored;
  }
  return null;
};

const requireSession = (): { db: MockDb; user: MockUser; token: string } => {
  const token = resolveSessionToken();
  if (!token) throw new HttpError(401, "You are not signed in.");

  const db = loadDb();
  const session = db.sessions[token];
  if (!session) throw new HttpError(401, "Your session expired. Please sign in again.");
  const user = db.users.find((item) => item.id === session.userId);
  if (!user) throw new HttpError(401, "Account not found. Please sign in again.");
  return { db, user, token };
};

const persistDbUser = (db: MockDb, updatedUser: MockUser) => {
  const index = db.users.findIndex((item) => item.id === updatedUser.id);
  if (index === -1) return;
  db.users[index] = updatedUser;
  saveDb(db);
};

const setVerificationCode = (code: string) => {
  if (!isBrowser) return;
  window.localStorage.setItem(MOCK_STORAGE_KEYS.lastVerificationCode, code);
};

const setResetToken = (token: string) => {
  if (!isBrowser) return;
  window.localStorage.setItem(MOCK_STORAGE_KEYS.lastResetToken, token);
};

const clearSession = (token: string | null, db: MockDb) => {
  if (token && db.sessions[token]) {
    delete db.sessions[token];
    saveDb(db);
  }
  removeStorage(SESSION_STORAGE_KEY);
};

type ApiResponse<T> = Promise<{ data: T }>;

type PostBody = Record<string, unknown> | undefined;

type RouteHandler = (body?: PostBody) => ApiResponse<any>;

type RouteMap = Record<string, RouteHandler>;

const postHandlers: RouteMap = {
  "/auth/login": async (body) => {
    await delay();
    const email = String(body?.email || "").trim().toLowerCase();
    const password = String(body?.password || "");
    if (!email || !password) throw new HttpError(400, "Email and password are required.");

    const db = loadDb();
    const user = db.users.find((item) => item.email.toLowerCase() === email);
    if (!user || user.password !== password) throw new HttpError(401, "Invalid email or password.");

    const token = randomToken();
    db.sessions[token] = { userId: user.id, created_at: now() };
    saveDb(db);
    if (isBrowser) {
      window.localStorage.setItem(SESSION_STORAGE_KEY, token);
    }

    return { data: { user: toPublicUser(user), access_token: token } as LoginResponse };
  },
  "/auth/register": async (body) => {
    await delay();
    const first_name = String(body?.first_name || "").trim();
    const last_name = String(body?.last_name || "").trim();
    const email = String(body?.email || "").trim().toLowerCase();
    const password = String(body?.password || "");

    if (!first_name || !last_name || !email || !password) {
      throw new HttpError(400, "All fields are required.");
    }

    const db = loadDb();
    const existing = db.users.find((item) => item.email.toLowerCase() === email);
    if (existing) throw new HttpError(409, "Email is already registered.");

    const code = randomCode();
    const timestamp = now();
    const user: MockUser = {
      id: randomId(),
      first_name,
      last_name,
      email,
      password,
      isVerified: false,
      created_at: timestamp,
      updated_at: timestamp,
      verifyCode: code,
      resetToken: null,
    };

    db.users.push(user);
    saveDb(db);
    setVerificationCode(code);
    if (isBrowser) {
      window.localStorage.setItem("hyow_pending_email", email);
    }

    return { data: { message: "Registered" } };
  },
  "/auth/verify-email": async (body) => {
    await delay();
    const email = String(body?.email || "").trim().toLowerCase();
    const code = String(body?.code || "").trim();

    if (!email || !code) throw new HttpError(400, "Email and code are required.");

    const db = loadDb();
    const user = db.users.find((item) => item.email.toLowerCase() === email);
    if (!user) throw new HttpError(404, "No account found for that email.");
    if (user.isVerified) return { data: { message: "Already verified" } };
    if (user.verifyCode !== code) throw new HttpError(400, "Invalid verification code.");

    user.isVerified = true;
    user.updated_at = now();
    user.verifyCode = null;
    persistDbUser(db, user);
    setVerificationCode(code);

    return { data: { message: "Email verified" } };
  },
  "/auth/resend-verification": async (body) => {
    await delay();
    const email = String(body?.email || "").trim().toLowerCase();
    if (!email) throw new HttpError(400, "Email is required.");

    const db = loadDb();
    const user = db.users.find((item) => item.email.toLowerCase() === email);
    if (!user) throw new HttpError(404, "No account found for that email.");
    if (user.isVerified) throw new HttpError(400, "Email is already verified.");

    const code = randomCode();
    user.verifyCode = code;
    user.updated_at = now();
    persistDbUser(db, user);
    setVerificationCode(code);

    return { data: { message: "Verification code resent" } };
  },
  "/auth/forgot-password": async (body) => {
    await delay();
    const email = String(body?.email || "").trim().toLowerCase();
    if (!email) throw new HttpError(400, "Email is required.");

    const db = loadDb();
    const user = db.users.find((item) => item.email.toLowerCase() === email);
    if (!user) {
      // simulate silent success
      setResetToken(randomToken());
      return { data: { message: "If that account exists, you will receive a reset token." } };
    }

    const token = randomToken();
    user.resetToken = token;
    user.updated_at = now();
    persistDbUser(db, user);
    setResetToken(token);

    return { data: { message: "Reset token generated" } };
  },
  "/auth/reset-password": async (body) => {
    await delay();
    const token = String(body?.token || "").trim();
    const newPassword = String(body?.new_password || body?.password || "");
    if (!token || !newPassword) throw new HttpError(400, "Token and new password are required.");

    const db = loadDb();
    const user = db.users.find((item) => item.resetToken === token);
    if (!user) throw new HttpError(400, "Invalid or expired reset token.");

    user.password = newPassword;
    user.resetToken = null;
    user.updated_at = now();
    persistDbUser(db, user);
    setResetToken(token);

    return { data: { message: "Password updated" } };
  },
  "/auth/logout": async () => {
    await delay(150);
    const { db, token } = (() => {
      try {
        const session = requireSession();
        return { db: session.db, token: session.token };
      } catch (error) {
        return { db: loadDb(), token: resolveSessionToken() };
      }
    })();

    clearSession(token, db);
    setAccessToken(null);

    return { data: { message: "Logged out" } };
  },
  "/auth/refresh": async () => {
    await delay(150);
    const token = resolveSessionToken();
    if (!token) throw new HttpError(401, "Not authenticated.");

    const db = loadDb();
    if (!db.sessions[token]) throw new HttpError(401, "Session expired.");

    return { data: { access_token: token } as AuthTokens };
  },
};

const getHandlers: RouteMap = {
  "/auth/me": async () => {
    await delay(150);
    const { user } = requireSession();
    return { data: toPublicUser(user) };
  },
};

export const api = {
  async post<T>(path: string, body?: PostBody): ApiResponse<T> {
    const handler = postHandlers[path];
    if (!handler) throw new HttpError(404, `POST ${path} not implemented in mock API.`);
    const response = await handler(body);
    return response as { data: T };
  },
  async get<T>(path: string): ApiResponse<T> {
    const handler = getHandlers[path];
    if (!handler) throw new HttpError(404, `GET ${path} not implemented in mock API.`);
    const response = await handler();
    return response as { data: T };
  },
};

export default api;
