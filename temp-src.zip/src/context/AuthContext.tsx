import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import api, { getAccessToken, setAccessToken } from "@lib/api";
import type { User, LoginResponse, AuthTokens } from "@/types/auth";

type RegisterInput = {
  first_name: string;
  last_name: string;
  email: string;
  password: string;
};

type AuthContextType = {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<User>;
  register: (input: RegisterInput) => Promise<void>;
  verifyEmail: (email: string, code: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshMe: () => Promise<User | null>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        await refreshMe();
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const refreshMe = async (): Promise<User | null> => {
    try {
      if (!getAccessToken()) {
        const refreshed = await api.post<AuthTokens>("/auth/refresh", {});
        setAccessToken(refreshed.data.access_token);
      } else {
        await api.post<AuthTokens>("/auth/refresh", {});
      }
      const me = await api.get<User>("/auth/me");
      setUser(me.data);
      return me.data;
    } catch (error) {
      setAccessToken(null);
      setUser(null);
      return null;
    }
  };

  const login = async (email: string, password: string): Promise<User> => {
    const res = await api.post<LoginResponse>("/auth/login", { email, password });
    const { access_token, user: sessionUser } = res.data;
    setAccessToken(access_token);
    setUser(sessionUser);
    return sessionUser;
  };

  const register = async (input: RegisterInput) => {
    await api.post("/auth/register", input);
  };

  const verifyEmail = async (email: string, code: string) => {
    await api.post("/auth/verify-email", { email, code });
    await refreshMe();
  };

  const logout = async () => {
    try {
      await api.post("/auth/logout", {});
    } finally {
      setAccessToken(null);
      setUser(null);
    }
  };

  const value = useMemo(
    () => ({ user, loading, login, register, verifyEmail, logout, refreshMe }),
    [user, loading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuthContext = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuthContext must be used within AuthProvider");
  return ctx;
};
