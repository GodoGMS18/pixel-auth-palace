import { Routes, Route } from "react-router-dom";
import LoginPage from "@pages/auth/Login";
import RegisterPage from "@pages/auth/Register";
import VerifyEmailPage from "@pages/auth/VerifyEmail";
import ForgotPasswordPage from "@pages/auth/ForgotPassword";
import ResetPasswordPage from "@pages/auth/ResetPassword";
import ProtectedRoute from "@routes/ProtectedRoute";

// Example protected page placeholder
function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-950 text-white flex items-center justify-center">
      <div className="max-w-xl text-center">
        <h1 className="text-3xl font-bold mb-2">HYOW Dashboard</h1>
        <p className="text-gray-300">Protected content. Replace with your real app.</p>
      </div>
    </div>
  );
}

export default function AppRoutes() {
  return (
    <Routes>
      {/* public */}
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/verify-email" element={<VerifyEmailPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />
      {/* protected */}
      <Route element={<ProtectedRoute />}>
        <Route path="/" element={<Dashboard />} />
      </Route>
      {/* fallback */}
      <Route path="*" element={<LoginPage />} />
    </Routes>
  );
}
