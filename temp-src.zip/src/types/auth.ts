export type ID = string;

export interface User {
  id: ID;
  first_name: string;
  last_name: string;
  email: string;
  isVerified: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface AuthTokens {
  access_token: string;
}

export interface LoginResponse {
  user: User;
  access_token: string;
}

export interface ApiError {
  status: number;
  message: string;
  details?: unknown;
}
